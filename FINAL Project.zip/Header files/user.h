#ifndef USER_H_INCLUDED
#define USER_H_INCLUDED
#include <string>

using namespace std;

class User{
protected:
    string userName;
    string userId;
public:
    User() = default;
    User(string name, string id){
        userName = name;
        userId = id;
    }
    string getUserName(){
        return userName;
    }
    string getUserId(){
        return userId;
    }
    // pure virtual function
    virtual string getUserStatus()=0;
};
#endif // USER_H_INCLUDED
