#ifndef FOOD_STRUCT_H_INCLUDED
#define FOOD_STRUCT_H_INCLUDED
#include <vector>

using namespace std;

struct foodInfo{
    vector<vector<string>> info;
    vector<vector<string>> prefer;
};

#endif // FOOD_STRUCT_H_INCLUDED
