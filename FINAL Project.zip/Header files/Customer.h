#ifndef CUSTOMER_H_INCLUDED
#define CUSTOMER_H_INCLUDED#include <string>
#include "user.h"

using namespace std;

class Customer : public User{
private:
    string userPassword;
    string Address;
    string status;
    double distance;
    int loyaltyPoints;
public:
    Customer() = default;
    Customer(string name,
             string id,
             string stats,
             string password,
             string address,
             double dist, int point):User(name,id){
        userPassword = password;
        Address = address;
        distance = dist;
        status = stats;
        loyaltyPoints = point;
    }
    // set points when reading from file
    void setPoints(int p){
        loyaltyPoints = p;
    }
    // get customer's password
    string getUserPassword(){
        return userPassword;
    }
    // get address
    string getAddress(){
        return Address;
    }
    // get points
    int getPoints(){
        return loyaltyPoints;
    }
    // get address distance (calculate delivery fee)
    double getDistance(){
        return distance;
    }
    // get customer status
    string getUserStatus() override {
        return status;
    }
};

#endif // CUSTOMER_H_INCLUDED
