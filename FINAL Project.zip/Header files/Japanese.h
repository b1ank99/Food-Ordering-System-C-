#ifndef JAPANESE_H_INCLUDED
#define JAPANESE_H_INCLUDED
#include <vector>
#include "Food.h"
using namespace std;

class Japanese : public Food{
    private:
        string variant;
        string preference;
        string specialInstruction;
        bool addPreference;
        vector<string> preferenceList;
    public:
        Japanese() = default;
        Japanese(string name, double price, string var, bool aP, vector<string> listPrefer = {}):
            Food(price, name){
            variant = var;
            addPreference = aP;
            preferenceList = listPrefer;
        }

        // set special instructions for food
        void setInstruction(string instr){
            specialInstruction = instr;
        }
        // set preference of specific food item
        void setPreference(string prefer){
            preference = prefer;
        }
        // check if food item has preference choice
        bool hasPreference(){
            return addPreference;
        }
        // get selected preference
        string getPreference(){
            return preference;
        }
        // get food type/cuisine
        string getFoodVariant() override{
            return variant;
        }
        // if has preference choice, return the list of choice
        vector<string> hasPrefrenceSelection() override{
            if(addPreference){
                return preferenceList;
            }
        }
        // get special instruction of food item
        string getInstruction() override{
            return specialInstruction;
        }
};
#endif // JAPANESE_H_INCLUDED
