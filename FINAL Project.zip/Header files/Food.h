#ifndef FOOD_H_INCLUDED
#define FOOD_H_INCLUDED

class Food{
    protected:
        double foodPrice;
        string foodName;
    public:
        Food() = default;
        Food(double price, string name){
            foodPrice = price;
            foodName = name;
        }

        double getFoodPrice(){
            return foodPrice;
        }

        string getFoodName(){
            return foodName;
        }
        // pure virtual function
        virtual string getFoodVariant() = 0;
        virtual vector<string> hasPrefrenceSelection() = 0;
        virtual string getInstruction() = 0;
};

#endif // FOOD_H_INCLUDED
