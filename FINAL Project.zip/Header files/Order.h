#ifndef ORDER_H_INCLUDED
#define ORDER_H_INCLUDED
#include <vector>
#include <sstream>
#include <fstream>
#include <string>
#include "user.h"
#include "Customer.h"
#include "Rider.h"
#include "Restaurant.h"
#include "Food.h"
#include "Western.h"
#include "Japanese.h"
#include "Chinese.h"
#include "Malay.h"
#include "Arabic.h"
#include "orderDetails.h"

using namespace std;

class Order{
    private:
        Customer customer;
        orderDetails order;
        vector<orderDetails> allOrders;
        vector<orderDetails> individualOrders;
    public:
        Order() = default;
        // add / hold new and old orders
        void addAllorders(orderDetails ord){
            allOrders.push_back(ord);
        }
        // set customer for this order
        void setCustomer(Customer c){
            customer = c;
        }
        // get specific customer's order history
        vector<orderDetails> getHistory(){
            individualOrders.clear();
            for(auto& order : allOrders){
                if(order.getId() == customer.getUserId()){
                    individualOrders.push_back(order);
                }
            }

            return individualOrders;
        }
        // get order history from file
        void readHistory(const string& filename){
            ifstream file(filename);

            if (!file.is_open()) {
                cerr << "Could not open the file: " << filename << endl;
                return;
            }
            string line;
            if(getline(file, line))
            string line;
            while (getline(file, line)) {
                stringstream ss(line);
                string value;
                orderDetails ord;
                vector<string> values;
                int i = 0;
                while (getline(ss, value, ',')) {
                    values.push_back(value);
                }
                string id = values[0];
                ord = orderDetails(id, values[i+2], values[i+1]);
                i+=3;
                ord.setSubtotal(stod(values[i]));
                i++;
                ord.setDeliveryFee(stod(values[i]));
                i++;
                ord.setTotal(stod(values[i]));
                i++;
                ord.setDelivery(values[i]);
                i++;
                ord.setUniqueId(values[i]);
                i++;
                // 8
                while(values[i] != "amount"){
                    vector<string> prefer;
                    if(values[2] == "western"){
                        if(values[i+3] == "1"){
                            prefer.push_back(values[i+4]);
                            prefer.push_back(values[i+5]);
                            Western food(values[i], stod(values[i+1]), values[i+2], (values[i+3]=="1")? true:false, prefer);
                            i+=6;
                            food.setInstruction(values[i]);
                            i++;
                            food.setPreference(values[i]);
                            i++;
                            ord.addWesternOrder(food);
                        }
                        else{
                            Western food(values[i], stod(values[i+1]), values[i+2], (values[i+3]=="1")? true:false);
                            i+=4;
                            food.setInstruction(values[i]);
                            i++;
                            food.setPreference(values[i]);
                            i++;
                            ord.addWesternOrder(food);
                        }
                    }
                    else if(values[2] == "japanese"){
                        if(values[i+3] == "1"){
                            prefer.push_back(values[i+4]);
                            prefer.push_back(values[i+5]);
                            Japanese food(values[i], stod(values[i+1]), values[i+2], (values[i+3]=="1")? true:false, prefer);
                            i+=6;
                            food.setInstruction(values[i]);
                            i++;
                            food.setPreference(values[i]);
                            i++;
                            ord.addJapaneseOrder(food);
                        }
                        else{
                            Japanese food(values[i], stod(values[i+1]), values[i+2], (values[i+3]=="1")? true:false);
                            i+=4;
                            food.setInstruction(values[i]);
                            i++;
                            food.setPreference(values[i]);
                            i++;
                            ord.addJapaneseOrder(food);
                        }
                    }
                    else if(values[2] == "chinese"){
                        if(values[i+3] == "1"){
                            prefer.push_back(values[i+4]);
                            prefer.push_back(values[i+5]);
                            Chinese food(values[i], stod(values[i+1]), values[i+2], (values[i+3]=="1")? true:false, prefer);
                            i+=6;
                            food.setInstruction(values[i]);
                            i++;
                            food.setPreference(values[i]);
                            i++;
                            ord.addChineseOrder(food);
                        }
                        else{
                            Chinese food(values[i], stod(values[i+1]), values[i+2], (values[i+3]=="1")? true:false);
                            i+=4;
                            food.setInstruction(values[i]);
                            i++;
                            food.setPreference(values[i]);
                            i++;
                            ord.addChineseOrder(food);
                        }
                    }
                    else if(values[2] == "malay"){
                        if(values[i+3] == "1"){
                            prefer.push_back(values[i+4]);
                            prefer.push_back(values[i+5]);
                            Malay food(values[i], stod(values[i+1]), values[i+2], (values[i+3]=="1")? true:false, prefer);
                            i+=6;
                            food.setInstruction(values[i]);
                            i++;
                            food.setPreference(values[i]);
                            i++;
                            ord.addMalayOrder(food);
                        }
                        else{
                            Malay food(values[i], stod(values[i+1]), values[i+2], (values[i+3]=="1")? true:false);
                            i+=4;
                            food.setInstruction(values[i]);
                            i++;
                            food.setPreference(values[i]);
                            i++;
                            ord.addMalayOrder(food);
                        }
                    }
                    else if(values[2] == "arabic"){
                        if(values[i+3] == "1"){
                            prefer.push_back(values[i+4]);
                            prefer.push_back(values[i+5]);
                            Arabic food(values[i], stod(values[i+1]), values[i+2], (values[i+3]=="1")? true:false, prefer);
                            i+=6;
                            food.setInstruction(values[i]);
                            i++;
                            food.setPreference(values[i]);
                            i++;
                            ord.addArabicOrder(food);
                        }
                        else{
                            Arabic food(values[i], stod(values[i+1]), values[i+2], (values[i+3]=="1")? true:false);
                            i+=4;
                            food.setInstruction(values[i]);
                            i++;
                            food.setPreference(values[i]);
                            i++;
                            ord.addArabicOrder(food);
                        }
                    }

                }
                i++;
                for (int j = i; j < values.size(); j++){
                    ord.updateAmount(stoi(values[j]));
                }
                addAllorders(ord);
            }
            file.close();
        }
        // save new order into the file
        void writeHistory(const string& filename){
            ofstream file(filename, ios::out);
            if (!file.is_open()) {
                cerr << "Could not open the file: " << filename << std::endl;
                return;
            }
            file << "History";
            file << "\n";
            for(auto& order : allOrders){
                file << order.getId();
                file << ",";
                file << order.getRestaurant();
                file << ",";
                file << order.getCuisine();
                file << ",";
                file << order.getSubtotal();
                file << ",";
                file << order.getDeliveryFee();
                file << ",";
                file << order.getTotal();
                file << ",";
                file << order.getDeliver();
                file << ",";
                file << order.getUniqueId();
                file << ",";
                if(order.getCuisine() == "western"){
                    for(auto& food : order.getWesternFood()){
                        file << food.getFoodName();
                        file << ",";
                        file << food.getFoodPrice();
                        file << ",";
                        file << food.getFoodVariant();
                        file << ",";
                        file << food.hasPreference();
                        file << ",";
                        if(food.hasPreference()){
                            vector<string> listPrefer = food.hasPrefrenceSelection();
                            for(auto& prefer : listPrefer){
                                file << prefer;
                                file << ",";
                            }
                        }
                        file << food.getInstruction();
                        file << ",";
                        file << food.getPreference();
                        file << ",";
                    }
                }
                else if(order.getCuisine() == "japanese"){
                    for(auto& food : order.getJapaneseFood()){
                        file << food.getFoodName();
                        file << ",";
                        file << food.getFoodPrice();
                        file << ",";
                        file << food.getFoodVariant();
                        file << ",";
                        file << food.hasPreference();
                        file << ",";
                        if(food.hasPreference()){
                            vector<string> listPrefer = food.hasPrefrenceSelection();
                            for(auto& prefer : listPrefer){
                                file << prefer;
                                file << ",";
                            }
                        }
                        file << food.getInstruction();
                        file << ",";
                        file << food.getPreference();
                        file << ",";
                    }
                }
                else if(order.getCuisine() == "chinese"){
                    for(auto& food : order.getChineseFood()){
                        file << food.getFoodName();
                        file << ",";
                        file << food.getFoodPrice();
                        file << ",";
                        file << food.getFoodVariant();
                        file << ",";
                        file << food.hasPreference();
                        file << ",";
                        if(food.hasPreference()){
                            vector<string> listPrefer = food.hasPrefrenceSelection();
                            for(auto& prefer : listPrefer){
                                file << prefer;
                                file << ",";
                            }
                        }
                        file << food.getInstruction();
                        file << ",";
                        file << food.getPreference();
                        file << ",";
                    }
                }
                else if(order.getCuisine() == "malay"){
                    for(auto& food : order.getMalayFood()){
                        file << food.getFoodName();
                        file << ",";
                        file << food.getFoodPrice();
                        file << ",";
                        file << food.getFoodVariant();
                        file << ",";
                        file << food.hasPreference();
                        file << ",";
                        if(food.hasPreference()){
                            vector<string> listPrefer = food.hasPrefrenceSelection();
                            for(auto& prefer : listPrefer){
                                file << prefer;
                                file << ",";
                            }
                        }
                        file << food.getInstruction();
                        file << ",";
                        file << food.getPreference();
                        file << ",";
                    }
                }
                else if(order.getCuisine() == "arabic"){
                    for(auto& food : order.getArabicFood()){
                        file << food.getFoodName();
                        file << ",";
                        file << food.getFoodPrice();
                        file << ",";
                        file << food.getFoodVariant();
                        file << ",";
                        file << food.hasPreference();
                        file << ",";
                        if(food.hasPreference()){
                            vector<string> listPrefer = food.hasPrefrenceSelection();
                            for(auto& prefer : listPrefer){
                                file << prefer;
                                file << ",";
                            }
                        }
                        file << food.getInstruction();
                        file << ",";
                        file << food.getPreference();
                        file << ",";
                    }
                }
                file << "amount";
                file << ",";
                int i = 0;
                for(auto& a : order.getAmount()){
                    file << a;
                    if (i < order.getAmount().size() - 1) {
                        file << ",";
                    }
                    i++;
                }
                file << "\n";
            }

            file.close();
        }
};

#endif // ORDER_H_INCLUDED
