#ifndef RIDER_H_INCLUDED
#define RIDER_H_INCLUDED
#include "user.h"

using namespace std;

class Rider : public User{
private:
    string status;
    string color;
    string model;
    string plate;
public:
    Rider() = default;
    Rider(string name, string id, string stats, string m, string c, string p):User(name,id){
        status = stats;
        model = m;
        color = c;
        plate = p;
    }
    // implement virtual function
    string getUserStatus() override {
        return status;
    }

    // get deliver transport details
    string getColor(){
        return color;
    }
    string getTransport(){
        return model;
    }
    string getPlate(){
        return plate;
    }
};

#endif // RIDER_H_INCLUDED
