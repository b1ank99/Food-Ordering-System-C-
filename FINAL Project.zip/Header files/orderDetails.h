#ifndef ORDERDETAILS_H_INCLUDED
#define ORDERDETAILS_H_INCLUDED
#include <vector>

#include "user.h"
#include "Customer.h"
#include "Rider.h"
#include "Restaurant.h"
#include "Food.h"
#include "Western.h"
#include "Japanese.h"
#include "Chinese.h"
#include "Malay.h"
#include "Arabic.h"

using namespace std;

class orderDetails{
    private:
        static int totalOrder;
        string customerId;
        string uniqueId;
        string cuisine;
        string restaurant;
        Customer cus;
        Rider rider;
        vector<Western> orderedFoodW;
        vector<Japanese> orderedFoodJ;
        vector<Chinese> orderedFoodC;
        vector<Malay> orderedFoodM;
        vector<Arabic> orderedFoodA;
        vector<int> amount;
        string deliver;
        double deliveryFee;
        double subtotal;
        double total;
        double discount;
        double dist;
        // calculate delivery fee based on :
        // methods and distance of customer's address to restaurant
        // assume all restaurants are in a same place
        void calcDeliveryFee(){
        // calculate subtotal based on ordered food items
            double distFee;
            // fee based on distance
            // < 1km Rm0, <= 5km RM2, <= 10km RM4
            if(dist <= 1){
                distFee = 0;
            }
            else if(dist <= 5){
                distFee = 2;
            }
            else if(dist <= 10){
                distFee = 4;
            }

            if(deliver == "direct"){
                deliveryFee = 5+distFee;
            }
            else if(deliver == "standard"){
                deliveryFee = 3+distFee;
            }
            else if(deliver == "saver"){
                deliveryFee = 1+distFee;
            }
            // free delivery if this is 10th purchase in app
            if(free())
                deliveryFee = 0;
        }
        void calcSubtotal(){
            subtotal = 0;
            int i = 0;
            if(cuisine=="western"){
                for(auto& food : orderedFoodW){
                    subtotal += food.getFoodPrice()*amount[i];
                    i++;
                }
            }
            else if(cuisine=="japanese"){
                for(auto& food : orderedFoodJ){
                    subtotal += food.getFoodPrice()*amount[i];
                    i++;
                }
            }
            else if(cuisine=="chinese"){
                for(auto& food : orderedFoodC){
                    subtotal += food.getFoodPrice()*amount[i];
                    i++;
                }
            }
            else if(cuisine=="malay"){
                for(auto& food : orderedFoodM){
                    subtotal += food.getFoodPrice()*amount[i];
                    i++;
                }
            }
            else if(cuisine=="arabic"){
                for(auto& food : orderedFoodA){
                    subtotal += food.getFoodPrice()*amount[i];
                    i++;
                }
            }
        }
        // read file and get number of total order
        static void setStatic(){
            ifstream file("total purchase index.csv");

            if (!file.is_open()) {
                cerr << "Could not open the file: " << "total purchase index.csv" << endl;
                return;
            }
            string line;
            if(getline(file, line))
            string line;
            while (getline(file, line)) {
                stringstream ss(line);
                string value;
                vector<string> values;
                while (getline(ss, value, ',')) {
                    values.push_back(value);
                }
            totalOrder = stoi(values[0]);

            file.close();
            }

        }
        // update points after puchase
        void updatePoint(){
            cus.setPoints(cus.getPoints()+total);
        }
        // calculate if customer apply an discount for this order
        void calcDiscount(){
            discount = total/(subtotal+deliveryFee);
        }
    public:
        orderDetails() = default;
        // constructor to hold past order
        orderDetails(string id, string cuis, string res){
            customerId = id;
            cuisine = cuis;
            restaurant = res;
            setStatic();
        }
        // constructor for new food order
        orderDetails(Customer c, string cuis, string res){
            cus = c;
            customerId = cus.getUserId();
            cuisine = cuis;
            restaurant = res;
            setStatic();
        }
        // class for throwing if input not valid
        class deliveryOption{
            private:
                bool opt = false;
            public:
                deliveryOption() = default;
                deliveryOption(int n){
                    opt = true;
                }

                bool getOpt(){
                    return opt;
                }
        };
        // class for throwing if input not valid
        class loyalPoint{
        public:
            void displayMsg(){
                cout << "Invalid Input." << endl;
            }
        };
        // check if it is 10th order or not
        static bool free(){
            if(totalOrder%10 == 0)
                return true;
            else
                return false;
        }
        // set subtotal when reading from file
        void setSubtotal(double n){
            subtotal = n;
        }
        // set delivery fee when reading from file
        void setDeliveryFee(double n){
            deliveryFee = n;
        }
        // set total
        void setTotal(double n){
            total = n;
        }
        // set unique id to this order
        void setUniqueId(string id){
            uniqueId = id;
        }
        // set customer for this order
        void setCustomer(Customer c){
            cus = c;
            customerId = cus.getUserId();
        }
        // generate random and unique order ID
        void generateUniqueId(){
            string x = "1234567890ABCDE";
            uniqueId.clear();
            for(int i = 0; i<=6; i++){
                uniqueId+=x[rand()%7];
            }
        }
        // set delivery option and increment the total purchase
        void setDelivery(int n, double distance){
            if(cin.fail()){
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(),'\n');
                throw deliveryOption();
            }
            if(n>3 || n<1){
                throw deliveryOption(n);
            }

            if(n==1)
                deliver = "direct";
            else if(n==2){
                deliver = "standard";
            }
            else if(n==3){
                deliver = "saver";
            }
            dist = distance;
            totalOrder += 1;
            ofstream file("total purchase index.csv", ios::out);
            if (!file.is_open()) {
                cerr << "Could not open the file: " << "total purchase index.csv" << std::endl;
                return;
            }
            file << "idx";
            file << "\n";
            file << totalOrder;
            file << "\n";

            file.close();
            calcDeliveryFee();

        }
        // set delivery option (when read from file)
        void setDelivery(string d){
            deliver = d;
        }
        // check if customer select any food item
        // determine if this order valid or not
        bool hasNoOrder(){
            if(cuisine == "western")
                return orderedFoodW.empty();
            else if(cuisine == "japanese")
                return orderedFoodJ.empty();
            else if(cuisine == "chinese")
                return orderedFoodC.empty();
            else if(cuisine == "malay")
                return orderedFoodM.empty();
            else if(cuisine == "arabic")
                return orderedFoodA.empty();
        }
        // add food item ordered according to cuisine
        void addWesternOrder(Western food){
            orderedFoodW.push_back(food);
        }
        void addJapaneseOrder(Japanese food){
            orderedFoodJ.push_back(food);
        }
        void addChineseOrder(Chinese food){
            orderedFoodC.push_back(food);
        }
        void addMalayOrder(Malay food){
            orderedFoodM.push_back(food);
        }
        void addArabicOrder(Arabic food){
            orderedFoodA.push_back(food);
        }
        // update amount of food item selected or ordered
        void updateAmount(int n){
            amount.push_back(n);
            calcSubtotal();
        }
        // get cuisine of this order
        string getCuisine(){
            return cuisine;
        }
        // get customer id for display purpose
        string getId(){
            return customerId;
        }
        // return customer for updating points
        Customer getCustomer(){
            return cus;
        }
        // return restaurant
        string getRestaurant(){
            return restaurant;
        }
        // get order id for display purpose
        string getUniqueId(){
            return uniqueId;
        }
        // get delivery fee
        double getDeliveryFee(){
            return deliveryFee;
        }
        // get delivery option
        string getDeliver(){
            return deliver;
        }
        // get subtotal
        double getSubtotal(){
            return subtotal;
        }
        // discount for display, if any
        double getDiscount(){
            return discount;
        }
        // calculate total
        void CalcTotal(){
            total = subtotal + deliveryFee;
        }
        // calculate total if 50% discount applied using 300 points
        void CalcTotal(int c){
            total = (subtotal + deliveryFee) * discount;
        }
        // get total while at the same time calculate if any discount applied
        double getTotal(){
            calcDiscount();
            return total;
        }
        // get customer's point
        int getPoint(){
            return cus.getPoints();
        }
        // check customer input and apply discount using 300 points
        void useLoyaltyPoints(int c){
            if(cin.fail()){
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(),'\n');
                throw loyalPoint();
            }
            if(c<1 || c>2){
                string msg = "Out of range";
                throw loyalPoint();
            }
            if(c == 1){
                discount = 0.5;
                cus.setPoints(cus.getPoints()-300);
            }
            else
                discount = 1;
            CalcTotal(c);
        }
        // get all ordered food item amount
        vector<int> getAmount(){
            return amount;
        }
        // assign rider
        void getRide(Rider rid){
            rider = rid;
        }
        // get vector of ordered food
        vector<Western> getWesternFood(){
            return orderedFoodW;
        }
        vector<Japanese> getJapaneseFood(){
            return orderedFoodJ;
        }
        vector<Chinese> getChineseFood(){
            return orderedFoodC;
        }
        vector<Malay> getMalayFood(){
            return orderedFoodM;
        }
        vector<Arabic> getArabicFood(){
            return orderedFoodA;
        }
        // check if customer has enough points for valid exchange of 50% discount
        bool hasPoints(){
            if(cus.getPoints() < 300)
                return false;
            else
                return true;
        }
        // display ordered food and its amount, preference and special instruction
        void displayDetails(){
            int i = 0;
            if (cuisine == "western"){
                for(auto& food : orderedFoodW){
                    cout << food.getFoodName() << endl;
                    if(food.hasPreference()){
                        cout << "Preference: " << food.getPreference() << endl;
                    }
                    Food* f = &food;
                    cout << "Special Instruction: " << f->getInstruction() << endl;
                    cout << "RM" << food.getFoodPrice() << " x";
                    cout << amount[i] << endl;
                    cout << endl;
                    i++;
                }
            }
            else if (cuisine == "japanese"){
                for(auto& food : orderedFoodJ){
                    cout << food.getFoodName() << endl;
                    if(food.hasPreference()){
                        cout << "Preference: " << food.getPreference() << endl;
                    }
                    Food* f = &food;
                    cout << "Special Instruction: " << f->getInstruction() << endl;
                    cout << "RM" << food.getFoodPrice() << " x";
                    cout << amount[i] << endl;
                    cout << endl;
                    i++;
                }
            }
            else if (cuisine == "chinese"){
                for(auto& food : orderedFoodC){
                    cout << food.getFoodName() << endl;
                    if(food.hasPreference()){
                        cout << "Preference: " << food.getPreference() << endl;
                    }
                    Food* f = &food;
                    cout << "Special Instruction: " << f->getInstruction() << endl;
                    cout << "RM" << food.getFoodPrice() << " x";
                    cout << amount[i] << endl;
                    cout << endl;
                    i++;
                }
            }
            else if (cuisine == "malay"){
                for(auto& food : orderedFoodM){
                    cout << food.getFoodName() << endl;
                    if(food.hasPreference()){
                        cout << "Preference: " << food.getPreference() << endl;
                    }
                    Food* f = &food;
                    cout << "Special Instruction: " << f->getInstruction() << endl;
                    cout << "RM" << food.getFoodPrice() << " x";
                    cout << amount[i] << endl;
                    cout << endl;
                    i++;
                }
            }
            else if (cuisine == "arabic"){
                for(auto& food : orderedFoodA){
                    cout << food.getFoodName() << endl;
                    if(food.hasPreference()){
                        cout << "Preference: " << food.getPreference() << endl;
                    }
                    Food* f = &food;
                    cout << "Special Instruction: " << f->getInstruction() << endl;
                    cout << "RM" << food.getFoodPrice() << " x";
                    cout << amount[i] << endl;
                    cout << endl;
                    i++;
                }
            }

        }
        // display rider details
        void displayRider(){
            cout << "Name: " << rider.getUserName() << endl;
            cout << "Transport" << endl;
            cout << "Model: " << rider.getTransport() << endl;
            cout << "Color: " << rider.getColor() << endl;
            cout << "Plate Number: " << rider.getPlate() << endl;
            // update point as the order is confirmed
            updatePoint();
        }
        // get total orders
        static int getTotalOrder(){
            return totalOrder;
        }
};

#endif // ORDERDETAILS_H_INCLUDED
