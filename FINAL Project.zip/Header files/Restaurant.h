#ifndef RESTAURANT_H_INCLUDED
#define RESTAURANT_H_INCLUDED
#include <string>
#include "Food.h"
#include "Western.h"
#include "Japanese.h"
#include "Chinese.h"
#include "Malay.h"
#include "Arabic.h"

using namespace std;

class Restaurant{
    private:
        vector<Western> westernFood;
        vector<Japanese> japaneseFood;
        vector<Chinese> chineseFood;
        vector<Malay> malayFood;
        vector<Arabic> arabicFood;
        string restaurantName;
        string cuisine;
        vector<string> rating;
        vector<string> review;
        // add food item based on which cuisine the restaurant serves
        void addWesternFood(Western wes){
            westernFood.push_back(wes);
        }
        void addJapaneseFood(Japanese jap){
            japaneseFood.push_back(jap);
        }
        void addChineseFood(Chinese chi){
            chineseFood.push_back(chi);
        }
        void addMalayFood(Malay mal){
            malayFood.push_back(mal);
        }
        void addArabicFood(Arabic ara){
            arabicFood.push_back(ara);
        }
    public:
        Restaurant() = default;
        Restaurant(string name, string cuis){
            restaurantName = name;
            cuisine = cuis;
        }
        // set ratings & reviews from file
        void setRatingReview(string r, string rev){
            rating.push_back(r);
            review.push_back(rev);
        }
        // after rating & review, add record in file
        void addRatingReview(string rate, string review){
            ofstream file("Ratings & Review.csv", ios::app);
            if (!file.is_open()) {
                cerr << "Could not open the file: " << "Ratings & Review.csv" << std::endl;
                return;
            }
            file << rate + ((rate == "1")?" Star" : " Stars");
            file << ",";
            file << review;
            file << ",";
            file << restaurantName;
            file << "\n";
            file.close();
            cout << endl;
        }
        // get ratings
        vector<string> getRating(){
            // clear all previous rating and get latest rating from file
            rating.clear();
            review.clear();
            ifstream file("Ratings & Review.csv");
            string value;
            vector<string> values;
            vector<vector<string>> info;

            if (!file.is_open()) {
                cerr << "Could not open the file: " << "Ratings & Review.csv" << endl;
                return values;
            }
            string line;
            if(getline(file, line))
            string line;
            while (getline(file, line)) {
                stringstream ss(line);
                string value;
                vector<string> values;
                while (getline(ss, value, ',')) {
                    values.push_back(value);
                }

                info.push_back(values);
            }

            file.close();

            for(auto& x : info){
                if(x[2] == restaurantName){
                    setRatingReview(x[0], x[1]);
                }
            }

            return rating;
        }
        // get reviews
        vector<string> getReview(){
            return review;
        }
        // get the cuisine restaurant serves
        string getCuisine(){
            return cuisine;
        }
        // get restaurant name
        string getRestaurantName(){
            return restaurantName;
        }
        // get food items of the restaurant from file
        void existedFood(vector<string> x, vector<string> prefer = {}){
            if(cuisine == "western"){
                addWesternFood(Western(x[0], stod(x[1]), x[2], (x[3]=="TRUE") ? true:false, prefer));
            }
            else if(cuisine == "japanese"){
                addJapaneseFood(Japanese(x[0], stod(x[1]), x[2], (x[3]=="TRUE") ? true:false, prefer));
            }
            else if(cuisine == "chinese"){
                addChineseFood(Chinese(x[0], stod(x[1]), x[2], (x[3]=="TRUE") ? true:false, prefer));
            }
            else if(cuisine == "malay"){
                addMalayFood(Malay(x[0], stod(x[1]), x[2], (x[3]=="TRUE") ? true:false, prefer));
            }
            else if(cuisine == "arabic"){
                addArabicFood(Arabic(x[0], stod(x[1]), x[2], (x[3]=="TRUE") ? true:false, prefer));
            }
        }

        // return food items
        vector<Western> getWesternFood(){
            return westernFood;
        }
        vector<Japanese> getJapaneseFood(){
            return japaneseFood;
        }
        vector<Chinese> getChineseFood(){
            return chineseFood;
        }
        vector<Malay> getMalayFood(){
            return malayFood;
        }
        vector<Arabic> getArabicFood(){
            return arabicFood;
        }
};

#endif // RESTAURANT_H_INCLUDED
