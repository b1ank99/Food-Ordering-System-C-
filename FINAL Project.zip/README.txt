You can get customer ID and password inside user.csv file
Here is the ID for Dr Geetha
Id: gth123
Password: Geetha888

Please make sure main.cpp file, all header files and csv files are placed inside same directory to access or for the code to run properly.
Note that it may be to get the files out from the folder (I put the file inside folder for clear documentation purpose)

Inside report pdf file, if you cannot see the diagrams clearly, do open its original pdf files attached.

Thank you